import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, ArrowDown, Check, ChevronDown, CircleHelp, Clock3, Code2,
  Database, FileCheck2, Flag, Globe2, History, LayoutDashboard, ListChecks,
  MousePointer2, Play, Plus, Redo2, Save, Settings, Sparkles, Trash2,
  Type, Undo2, Upload, X, Zap
} from "lucide-react";
import "./styles.css";

const initialSteps = [
  { id: 1, type: "navigate", title: "Navigate to URL", desc: "Open the application", value: "http://localhost:5173" },
  { id: 2, type: "click", title: "Click on Patient Portal", desc: "Click the Patient Portal link/button", value: "text=Patient Portal" },
  { id: 3, type: "type", title: "Enter Phone Number", desc: "Type phone number", value: "9876543210", data: "phoneNumber" },
  { id: 4, type: "type", title: "Enter Password", desc: "Type password", value: "••••••••••", data: "password" },
  { id: 5, type: "click", title: "Click Login", desc: "Click the Login button", value: "text=Login" },
  { id: 6, type: "assert", title: "Assert URL", desc: "Verify redirected URL", value: "Expected: /patient" }
];

const actionTypes = [
  { type: "navigate", label: "Navigate", hint: "Open a URL in the browser", icon: Globe2 },
  { type: "click", label: "Click", hint: "Click on an element", icon: MousePointer2 },
  { type: "type", label: "Type", hint: "Enter text into an element", icon: Type },
  { type: "select", label: "Select", hint: "Select option from dropdown", icon: ListChecks },
  { type: "wait", label: "Wait", hint: "Wait for element or time", icon: Clock3 },
  { type: "assert", label: "Assert", hint: "Verify element, text or URL", icon: Check },
  { type: "screenshot", label: "Screenshot", hint: "Capture screenshot", icon: Upload }
];

function ActionIcon({ type, size=20 }) {
  const item = actionTypes.find(a => a.type === type);
  const Icon = item?.icon || Zap;
  return <Icon size={size} strokeWidth={2.2}/>;
}

function App() {
  const [steps, setSteps] = useState(initialSteps);
  const [activeNav, setActiveNav] = useState("Test Builder");
  const [running, setRunning] = useState(false);
  const [saved, setSaved] = useState(true);
  const [url, setUrl] = useState("http://localhost:5173");
  const [browser, setBrowser] = useState("Chromium");
  const [execution, setExecution] = useState("Headed");
  const [showData, setShowData] = useState(false);

  const addStep = (type) => {
    const meta = actionTypes.find(a => a.type === type);
    const newStep = {
      id: Date.now(),
      type,
      title: meta.label,
      desc: meta.hint,
      value: type === "navigate" ? url : type === "assert" ? "Expected: /patient" : "Configure value"
    };
    setSteps(s => [...s, newStep]);
    setSaved(false);
  };

  const removeStep = (id) => {
    setSteps(s => s.filter(x => x.id !== id));
    setSaved(false);
  };

  const runTest = () => {
    setRunning(true);
    setTimeout(() => setRunning(false), 2200);
  };

  const save = () => setSaved(true);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Sparkles size={19}/></div>
          <span>TestForge</span>
        </div>

        <nav className="nav">
          {[
            [LayoutDashboard, "Dashboard"],
            [ListChecks, "Test Builder"],
            [Activity, "Test Runs"],
            [History, "History"],
            [FileCheck2, "Reports"],
            [Settings, "Settings"]
          ].map(([Icon, label]) => (
            <button
              key={label}
              className={`nav-item ${activeNav === label ? "active" : ""}`}
              onClick={() => setActiveNav(label)}
            >
              <Icon size={19}/><span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <button className="icon-button"><CircleHelp size={18}/></button>
          <div className="profile">
            <div className="avatar">AS</div>
            <div><strong>Ananya Singh</strong><small>QA Engineer</small></div>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="title-area">
            <h1>Patient Login Test <span className="edit-dot">✎</span></h1>
            <span className={`save-state ${saved ? "saved" : "draft"}`}>
              {saved ? <Check size={14}/> : <span className="dot"/>}
              {saved ? "Saved" : "Draft"}
            </span>
          </div>
          <div className="toolbar">
            <button className="tool-btn"><Undo2 size={17}/></button>
            <button className="tool-btn"><Redo2 size={17}/></button>
            <button className="tool-btn danger"><Trash2 size={17}/></button>
            <button className="outline-btn" onClick={save}><Save size={16}/> Save</button>
            <button className="run-btn" onClick={runTest}>
              <Play size={16} fill="currentColor"/> {running ? "Running..." : "Run Test"}
            </button>
          </div>
        </header>

        <section className="workspace">
          <div className="config-panel">
            <div className="panel-heading">
              <h2>Test Flow</h2>
              <p>Configure your test and add actions</p>
            </div>

            <label>Basic Information</label>
            <div className="field">
              <span>Website URL</span>
              <div className="input-wrap"><Globe2 size={17}/><input value={url} onChange={e=>{setUrl(e.target.value);setSaved(false)}}/></div>
            </div>

            <div className="field">
              <span>Browser</span>
              <div className="select-wrap">
                <div className="browser-symbol">◉</div>
                <select value={browser} onChange={e=>setBrowser(e.target.value)}>
                  <option>Chromium</option><option>Firefox</option><option>WebKit</option>
                </select>
                <ChevronDown size={16}/>
              </div>
            </div>

            <div className="field">
              <span>Execution Mode</span>
              <div className="radio-row">
                <button className={`radio ${execution==="Headed" ? "chosen":""}`} onClick={()=>setExecution("Headed")}><span/> Headed</button>
                <button className={`radio ${execution==="Headless" ? "chosen":""}`} onClick={()=>setExecution("Headless")}><span/> Headless</button>
              </div>
            </div>

            <div className="tabs">
              <button className={!showData ? "selected":""} onClick={()=>setShowData(false)}>Actions</button>
              <button className={showData ? "selected":""} onClick={()=>setShowData(true)}>Data</button>
              <button>Assertions</button>
            </div>

            {!showData ? (
              <div className="action-list">
                {actionTypes.map(a => (
                  <button className={`action-item action-${a.type}`} key={a.type} onClick={()=>addStep(a.type)}>
                    <span className="action-icon"><ActionIcon type={a.type}/></span>
                    <span className="action-copy"><strong>{a.label}</strong><small>{a.hint}</small></span>
                    <span className="grip">⠿</span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="data-panel">
                <div className="data-card"><Database size={17}/><div><strong>phoneNumber</strong><small>9876543210</small></div></div>
                <div className="data-card"><Database size={17}/><div><strong>password</strong><small>Stored securely</small></div></div>
                <button className="add-data"><Plus size={16}/> Add variable</button>
              </div>
            )}
          </div>

          <div className="canvas">
            <div className="canvas-top">
              <button className="flow-pill"><Activity size={16}/> Test Flow</button>
              <div className="canvas-actions">
                <button className="secondary-pill"><Database size={15}/> Variables</button>
                <button className="data-pill" onClick={()=>setShowData(true)}><Code2 size={15}/> Data Flow</button>
              </div>
            </div>

            <div className="grid-bg"/>
            <div className="flow">
              <FlowNode start />
              {steps.map((step, i) => (
                <React.Fragment key={step.id}>
                  <div className="connector"><div className="plus">+</div></div>
                  <FlowNode step={step} onDelete={()=>removeStep(step.id)} />
                </React.Fragment>
              ))}
              <div className="connector"><div className="plus">+</div></div>
              <div className="finish-node">
                <div className="finish-icon"><Flag size={18}/></div>
                <div><strong>{running ? "Test Running" : "Test Completed"}</strong><small>{running ? "Executing browser automation..." : "All steps executed"}</small></div>
              </div>
            </div>

            <div className="minimap">
              <div className="mini-line green"/>
              {steps.map(s=><div key={s.id} className={`mini-line ${s.type}`}/>)}
              <div className="mini-line dark"/>
            </div>

            <div className="zoom">
              <button>−</button><span>100%</span><button>+</button><button>⛶</button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function FlowNode({ start, step, onDelete }) {
  if (start) return (
    <div className="flow-node start-node">
      <div className="start-icon"><Play size={18} fill="currentColor"/></div>
      <div><strong>Start Test</strong><small>Begin browser automation</small></div>
      <span className="kebab">⋮</span>
    </div>
  );

  return (
    <div className={`flow-node node-${step.type}`}>
      <div className="node-icon"><ActionIcon type={step.type}/></div>
      <div className="node-content">
        <strong>{step.title}</strong>
        <small>{step.desc}</small>
        <span className="value-chip">{step.value}</span>
      </div>
      <button className="node-delete" onClick={onDelete}>⋮</button>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
